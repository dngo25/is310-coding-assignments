Social Media Maze 
By Diana Ngo

Welcome player! Here are some instructions to guide you through this maze:
- There are 5 clues and each clue will lead you to the next!
- These clues are all centered around what you can find trending on socail media.
- I lied there is actually 6 clues, the 6th clue is hidden in on of the other clutes >:)
- Goodluck!
